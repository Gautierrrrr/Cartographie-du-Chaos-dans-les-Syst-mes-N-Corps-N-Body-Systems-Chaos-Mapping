from math import*
import numpy as np
import random
import matplotlib.pyplot as plt
from PIL import Image,ImageDraw


##############################################################################
######################### VITESSE INITIALE NON NULLE #########################
##############################################################################

com = np.zeros(5)  # compte nombre de fois chaque cas (crash sur chaque planète ou sortie)

#Calcul de la distance avec les pôles 
def Distance(x,y,X,Y,Nb_plots,i): 
    return sqrt((x-X[i])**2+(y-Y[i])**2) 
    


#Calcul des accélérations
def Acceleration(x,y,X,Y,k,Nb_poles):
    acc_x=0
    acc_y=0
    for i in range (Nb_poles):
        acc_x+=-k[i]*(x-X[i])/(Distance(x,y,X,Y,Nb_poles,i))**3
        acc_y+=-k[i]*(y-Y[i])/(Distance(x,y,X,Y,Nb_poles,i))**3
    return (acc_x,acc_y)


#On crée une condition d'arrêt qui s'applique si la distance entre notre point et le pôle est inférieur au rayon du plot 
def Condition_Arret(x,y,X,Y,Nb_poles,Rayon):
    for i in range(Nb_poles):
        if Distance(x,y,X,Y,Nb_poles,i)<=Rayon[i]:
            com[i] += 1  # une fois de plus couleur
            return (True)



def Sortie_cadre(x,y,X,Y,Dmax,Nb_poles):
    for i in range (Nb_poles):
        if Distance(x,y,X[i],Y[i],Nb_poles,i)>= Dist_max:
            com[4] += 1
            return (True)
        
        

def MethodeEuler_pas_variable(x,y,vx,vy,dt,dtmax):
    acceleration=Acceleration(x,y,X,Y,k,Nb_poles)
    acc_x=acceleration[0]
    acc_y=acceleration[1]
    dtmin=10**-8
    eps=10**-7
    
    vx_plus_dt=vx+dt*acc_x
    vy_plus_dt=vy+dt*acc_y
    
    if sqrt(vx**2+vy**2)==0:
        x_plus_dt=x+vx*dt
        y_plus_dt=y+vy*dt
        return(x_plus_dt,y_plus_dt,vx_plus_dt,vy_plus_dt,dt)
    
    Delta_v=sqrt(vx_plus_dt**2+vy_plus_dt**2)-sqrt(vx**2+vy**2)
    A=Delta_v/sqrt(eps+vx**2+vy**2) #On ajoute un terme epsilon très petit pour que le terme sous la racine ne soit pas nulle 
    dt=dtmin+(dtmax-dtmin)*(1/(A**2+1)) #On vait varier notre dt avec une fonction de type (1/1+x**2) et on borne notre dt
    
    x_plus_dt=x+dt*vx
    y_plus_dt=y+dt*vy

    return (x_plus_dt,y_plus_dt,vx_plus_dt,vy_plus_dt,dt)

 
    
#On crÃ©e une fonction qui calcule la trajectoire avec la mÃ©thode d'Euler Ã  pas variable
def Trajectoire_Euler_Pas_Variable(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs):
    t=0
    trajectoire_x=[x]
    trajectoire_y=[y]

    while t<=tmax:
        CA=Condition_Arret(x,y,X,Y,Nb_poles,Rayon)
        if CA==True:
            return (trajectoire_x, trajectoire_y)
        x,y,vx,vy,dt=MethodeEuler_pas_variable(x,y,vx,vy,dt,dtmax)
        trajectoire_x.append(x)
        trajectoire_y.append(y)
        t=t+dt
    com[4]+=1
    return (trajectoire_x,trajectoire_y)



##############################################################################
######################### VITESSE INITIALE NON NULLE #########################
##############################################################################

# =============================================================================
# REMARQUES :
# 
# - ATTENTION : IL FAUT QUE SEULE LA PARTIE TESTEE NE SOIT PAS COMMENTEE POUR LANCER SEULEMENT CETTE PARTIE
# 
# - POINTS ROUGES SIGNIFIENT QUE VARIABLES POUVANT ETRE MODIFIEES POUR TESTER DIFFERENTS CAS
# 
# - CHAQUE PARTIE A UNE CONFIGURATION DIFFERENTES ET DES PARAMETRES INITIAUX PROPRES
# =============================================================================


# =============================================================================
# # VITESSE ALÉATOIRE
# =============================================================================

# CHOIX DES PARAMETRES

Nb_poles=4
k=[1000,1000,1000,1000]

X=[150,  200,  50,   100]
#rouge,vert,bleu,jaune
Y=[75,  125,  75,   125]

Rayon=[2,2,2,2]
Couleurs=['r','g','b','y','k']
N=250
Dmax=500  # distance max du cadre

# composantes des vitesses initiales
Nv=5 # vitesse max
vx = random.uniform(-Nv, Nv)  
vy = random.uniform(-Nv, Nv) 

# position initiale 
x=125
y=150

print('vitesse initiale a norme : ', sqrt(vx**2 + vy**2))


# graphique configuration

# Disposition des plots
for n in range(Nb_poles):
    plt.scatter(X[n], Y[n], 70, c=Couleurs[n])

plt.scatter(x, y, 20, c='k')  # point de départ

# On trace la trajectoire en utilisant la méthode d'Euler pas variable

dtmax=10**-3 
dtmin=10**-8
t=dtmax/2
dtmin=10**-8      
dt=dtmax/2
max_iteration=300000  # 3 fois plus long
tmax=max_iteration*dtmax

TEPV=Trajectoire_Euler_Pas_Variable(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs) 
plt.plot(TEPV[0],TEPV[1],marker='',label='MÃ©thode Euler Ã  Pas Variable')
plt.title('Trajectoire vitesse aléatoire') 

plt.xlim(0,N)
plt.ylim(0,N)
plt.show()


# =============================================================================
# # NORME DE LA VITESSE
# =============================================================================   

# CHOIX DES PARAMETRES

Nb_poles=4
k=[1000,1000,1000,1000]

X=[50,  100,  150,   200]
#rouge,vert,bleu,jaune
Y=[75,  125,  175,   225]

Rayon=[2,2,2,2]
Couleurs=['r','g','b','y','k']
N=250

# position initiale
x = 20
y = 20


# temps
dtmax = 10**-3
t = dtmax / 2
dtmin = 10**-8      
dt = dtmax / 2
max_iteration = 100000
tmax = max_iteration * dtmax

# norme vitesse initiale grandeurs introduites

Nv = 20  # nombre de normes de la vitesse testées
Nt = 20 # nombre de normes de la vitesse testées proches de chaque vitesse, qui nous permettent d'étudier les issues de la comète
v = np.linspace(0, 5, Nv)  # Nv normes initiales de la vitesse de 0 à 5
com = np.zeros(5)  # compte nombre de fois chaque cas
chaos = np.zeros(Nv)  # mesure du chaos selon la vitesse initiale
pas = 1/10 * Nt  # écart entre chaque vitesse testée
 
# graphique configuration

# Disposition des plots
for n in range(Nb_poles):
    plt.scatter(X[n], Y[n], 70, c=Couleurs[n])

plt.scatter(x, y, 20, c='k')  # point de départ

plt.title('Configuration norme vitesse') 

plt.xlim(0, N)
plt.ylim(0, N)        
plt.show()
 

# mesure du chaos en fonction de la vitesse en mesurant l'écart type proche d'une certaine vitesse   

for j in range(Nv):  # Nv normes de vitesses

    x = 20  # position initiale
    y = 20
    v[j] = j / 10  # +0.1  pour chaque vitesse testée       
    vx = v[j] / sqrt(2)
    vy = v[j] / sqrt(2)
    com = np.zeros(5)  # compte nombre de fois chaque cas
    moy = Nt / len(com)  # moyenne pour écart type

   
    for m in range(Nt):  # Nt vitesses proches => Au total : Nv*Nt vitesses
        TEPV = Trajectoire_Euler_Pas_Variable(x, y, vx, vy, X, Y, dtmax, dt, Nb_poles, Rayon, Couleurs)  # donne commpteur grâce à Euler variable       
        vx += pas / sqrt(2)  # on ajoute au maximum : Nt*pas/sqrt2 = 1/10*sqrt(2)
        vy += pas / sqrt(2)
   
    # print(v[j], com)
   
    for i in range(len(com)):  
   
        chaos[j] += ((com[i] - moy)**2) / Nt  # variance  

    chaos[j] = -sqrt(chaos[j])  # chaos inversement proportionnel à l'écart type

for i in range(len(chaos)):  
   
    chaos[i] += -np.min(chaos)  # échelle entre 0 et chaos max      

          
# graphique chaos

plt.xlim(np.min(v), 1.1 * np.max(v))
plt.ylim(np.min(chaos), 1.1 * np.max(chaos))           
plt.plot(v, chaos)
plt.xlabel('Vitesse (m/s)')  
plt.ylabel('Chaos')
plt.title('Importance du chaos en fonction de la norme de la vitesse initiale')
plt.show()  


# # =============================================================================
# # # ANGLE VITESSE    
# # =============================================================================
   
# attention : grandeurs initiales adaptées pour meilleurs résultats pour mesure chaos

# INITIALISATION DES PARAMÈTRES

Nb_poles = 4
k = [1000, 1000, 1000, 1000]

X = [100, 150, 50, 100]
# rouge, vert, bleu, jaune
Y = [150, 100, 100, 50]

Rayon = [2, 2, 2, 2]
Couleurs = ['r', 'g', 'b', 'y', 'k']
N = 200
x = 100
y = 100

# temps
dtmax = 10**-3
t = dtmax / 2
dtmin = 10**-8      
dt = dtmax / 2
max_iteration = 100000
tmax = max_iteration * dtmax


# angle vitesse initiale grandeurs introduites

Nangle = 20  # nombre d'angles de vitesse
Nt = 25  # nombre d'angles de vitesse proches pour chaque angle de vitesse
R = 1
phi = np.zeros(Nangle)
chaos = np.zeros(Nangle)  # mesure du chaos selon l'angle initial
com = np.zeros(5)  # compte nombre de fois chaque cas


# graphique configuration

# Disposition des plots
for n in range(Nb_poles):
    plt.scatter(X[n], Y[n], 70, c=Couleurs[n])

plt.scatter(x, y, 20, c='k')  # point de départ

plt.title('Configuration angle vitesse') 

plt.xlim(0, N)
plt.ylim(0, N)        
plt.show()


# mesure du chaos en fonction de l'angle en mesurant l'écart type proche d'une certain angle

for j in range(Nangle):  # Nangle angles de vitesse

    x = 100
    y = 100
    phi[j] = j * 2 * pi / Nangle  # de 0 à 2*pi       
    vx = R * np.cos(phi[j])  # entre -R et R
    vy = R * np.sin(phi[j])
    com = np.zeros(5)  # compte nombre de fois chaque cas
    moy = Nt / len(com)  # moyenne pour écart type
   
    for m in range(Nt):  # Nt angles proches => Nangle*Nt angles
    
        TEPV = Trajectoire_Euler_Pas_Variable(x, y, vx, vy, X, Y, dtmax, dt, Nb_poles, Rayon, Couleurs)  # donne com        
        vx += R * np.cos(phi[j]) / 10 * Nt  # on teste angles proches pour chaque angle
        vy += R * np.sin(phi[j]) / 10 * Nt  # on ajoute au max R * np.sin(phi[j]) / 10
   
    # print('angle num', j, ',', 'angle :', phi[j], 'compteur', com)
   
    for i in range(len(com)):  
   
        chaos[j] += ((com[i] - moy)**2) / Nt  # variance  

    chaos[j] = -sqrt(chaos[j])  # chaos inversement proportionnel à l'écart type
   

for i in range(len(chaos)):  
    chaos[i] += -np.min(chaos)  # échelle entre 0 et chaos max      


# graphique chaos

plt.xlim(np.min(phi), 1.1 * np.max(phi))
plt.ylim(np.min(chaos), 1.1 * np.max(chaos))    
plt.plot(phi, chaos)
plt.xlabel('Angle (radians)')  
plt.ylabel('Chaos')
plt.title('Importance du chaos en fonction de l\'angle de la vitesse initiale')
plt.show()  


# # =============================================================================
# # # PLAN VITESSE INITIALE    
# # =============================================================================


# INITIALISATION DES PARAMÈTRES

Nb_poles = 4
k = [1000, 1000, 1000, 1000]

X = [150, 150, 50, 50]
# rouge, vert, bleu, jaune
Y = [150, 50, 150, 50]

Rayon = [2, 2, 2, 2]
Couleurs = ['r', 'g', 'b', 'y', 'k']
N = 200
x = 100
y = 100

# temps
dtmax = 10**-3
t = dtmax / 2
dtmin = 10**-8      
dt = dtmax / 2
max_iteration = 100000
tmax = max_iteration * dtmax


# grandeurs introduites

# ANGLE
Nangle = 8  # nombre d'angles de vitesse
Nanglemax = 2 * pi
phi = np.zeros(100 * Nangle)  # pour que la liste des angles de vitesse soit assez grande 
                                # car le pas d'angle diminue avec la norme dans la boucle ci-dessous

# NORME
Nv = 5  # nombre de normes de vitesse
Nvmax = 5
v = np.zeros(Nv * Nangle)
norme = 0

# points à peindre avec leurs couleurs
vxpeindre = []
vypeindre = []
couleurpeindre = []

# graphique configuration

# Disposition des plots
for n in range(Nb_poles):
    plt.scatter(X[n], Y[n], 70, c=Couleurs[n])

plt.scatter(x, y, 20, c='k')  # point de départ

plt.title('Configuration plan vitesse ') 

plt.xlim(0, N)
plt.ylim(0, N)        
plt.show()


# tracage vitesse dans son plan

for j in range(Nv):  # Nv normes de vitesses

    x = 100  # départ centre
    y = 100

    norme = j * Nvmax / Nv  # on balaie normes vitesse

    vxmax = norme / sqrt(2)  # vitesse max selon x (pour angle nul)
    vymax = norme / sqrt(2)  # vitesse max selon y (pour angle de pi/2)

    Nangle = Nangle + j**2  # plus de vitesses quand la norme est plus grande
   
    for m in range(Nangle):  # Nangle normes d'angles

        com = np.zeros(5)  # compte nombre de fois chaque cas

        phi[m] = m * Nanglemax / Nangle  # de 0 à 2*pi (tour complet)
   
        vx = vxmax * np.cos(phi[m])  # entre -1 * vx et 1 * vx
        vy = vymax * np.sin(phi[m])

        TEPV = Trajectoire_Euler_Pas_Variable(x, y, vx, vy, X, Y, dtmax, dt, Nb_poles, Rayon, Couleurs)  # donne compteur
   
        for i in range(len(com)):

            if com[i] == 1:
                # on peint vecteurs selon arrivee comete
                vxpeindre.append(vx)
                vypeindre.append(vy)
                couleurpeindre.append(Couleurs[i]) # couleur planete arrivee ou sortie
                plt.quiver(0, 0, vx, vy, width=0.005, color=Couleurs[i], angles='xy', scale_units='xy', scale=1) # on trace vecteurs


# graphique plan vitesse

plt.xlim(-Nvmax, Nvmax)
plt.ylim(-Nvmax, Nvmax)    
plt.xlabel('vx (m/s)')  
plt.ylabel('vy (m/s)')
plt.title('Vitesse initiale dans le plan')
plt.show()  


# # =============================================================================
# # # APPLICATION SYSTEME SOLAIRE
# # =============================================================================

# INITIALISATION DES PARAMÈTRES

# Nombre de corps 
Nb_poles = 11  # 10 planètes + Lune + Soleil
com = np.zeros(Nb_poles+1)  # compte nombre de fois chaque cas

# Potentiels attractifs proportionnels aux masses des astres 
k = [100000, 0.01, 0.1, 0.1, 0.001, 0.01, 100, 10, 1, 10, 0.001]  # selon ordre de grandeurs masses
# Soleil Mercure Vénus Terre Lune Mars Jupiter Saturne Uranus Neptune Pluton

# Données des astres
# Soleil Mercure Vénus Terre Lune Mars Jupiter Saturne Uranus Neptune Pluton
Rayon = [69.5, 0.25, 0.6, 0.65, 0.15, 0.35, 7.15, 6.05, 2.55, 2.5, 0.1] # e10**4 km
distance=[0.0, 6.25, 11.46, 15.62, 15.66, 23.96, 83.33, 145.83, 312.5, 458.33, 500.0] # distance par rapport au soleil adaptees au cadre

# Coordonnées X et Y des corps célestes (on aligne astres pour simplification)
X=np.zeros(Nb_poles)
Y=np.zeros(Nb_poles)

for i in range (Nb_poles):
    
    X[i] = 500 + distance [i]  # ditance par rapport soleil
    Y[i] = 500   

# Couleurs des astres
Couleurs = ['yellow', 'darkgrey', 'orange', 'blue', 'grey', 'red', 'brown', 'goldenrod', 'lightblue', 'blue', 'darkgrey']

N=1000
x=random.uniform(0,N)
y=random.uniform(0,N)
vx=0
vy=0



# graphique 

# tailles différentes
# for n in range(Nb_poles):
#         plt.scatter(X[n],Y[n],k[n]/100,c=Couleurs[n])  # proportionnel au potentiel attractif
        
# même tailles        
for n in range(Nb_poles):
        plt.scatter(X[n],Y[n],10,c=Couleurs[n])   # tous astres ont meme taille 

plt.scatter(x,y,20,c='k')  # point départ


# On trace la trajectoire en utilisant la méthode d'Euler pas variable

dtmax=10**-3 
dtmin=10**-8
t=dtmax/2
dtmin=10**-8      
dt=dtmax/2
max_iteration=1000000   # 10 fois plus long car cadre plus grand
tmax=max_iteration*dtmax

TEPV=Trajectoire_Euler_Pas_Variable(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs) 
plt.plot(TEPV[0],TEPV[1],marker='',label='MÃ©thode Euler Ã  Pas Variable')
 
plt.title('Trajectoire système solaire') 

plt.xlim(0,1.1*N)
plt.ylim(0,1.1*N)
plt.show()


# ##############################################################################
# ################################ FIN DU CODE #################################
# ##############################################################################




