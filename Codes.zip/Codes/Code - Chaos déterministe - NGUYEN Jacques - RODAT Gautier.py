from math import*
import numpy as np
import random
import matplotlib.pyplot as plt
from PIL import Image,ImageDraw

##############################################################################
####################### INITIALISATION DES PARAMETRES ########################
##############################################################################


Nb_poles=4
N=50 #On définit la dimension du cadre N*N
k=[7000,7900,8200,7500] #Valeur du potentiel des plots 
# k=[7000,7000,7000,7000] #k identiques

#Disposition des plots de façon quelconque pour cadre 150 x 150
# X=[47,70,89,110] #Position X des plots 
# Y=[42,80,56,90] #Position Y des plots 

#Disposition des plots de façon quelconque pour cadre 50 x 50 pour un test rapide (environ 3 à 5min)
X=[17,28,37,40]
Y=[17,20,30,35]

#Disposition des plots de façon symétrique 
# X=[25,25,75,75]
# Y=[N/3,2*N/3,N/3,2*N/3]

#Disposition des plots en forme de triangle équilatéral 
# X=[35,N/2,65]
# Y=[N/3,(N/3)+15*sqrt(3),N/3]

Rayon=[2,2,2,2] #Rayon des plots 
Couleurs=['r','g','b','m','k']
x=random.uniform(0,N)
y=random.uniform(0,N)
Dmax=500
#print('Conditions initiales (x0,y0):',x,y)
#Vitesses initiales
vx=0
vy=0
dt=10**-3 
dtmax=10**-3 
dtmin=10**-8

dt=dtmax/2
max_iteration=50000
tmax=max_iteration*dtmax


##############################################################################
################################### EULER ####################################
##############################################################################


#Disposition des plots 
for n in range(Nb_poles):
        plt.scatter(X[n],Y[n],100,c=Couleurs[n])
        
        
        
#Calcul de la distance avec les pôles 
def Distance(x,y,X,Y,Nb_plots,i): 
    return sqrt((x-X[i])**2+(y-Y[i])**2) 
    


#Calcul des accélérations
def Acceleration(x,y,X,Y,k,Nb_poles):
    acc_x=0
    acc_y=0
    for i in range (Nb_poles):
        acc_x+=-k[i]*(x-X[i])/(Distance(x,y,X,Y,Nb_poles,i))**3
        acc_y+=-k[i]*(y-Y[i])/(Distance(x,y,X,Y,Nb_poles,i))**3
    return (acc_x,acc_y)



#Calcul des coordonnées x et y ainsi que la vitesse selon x et selon y en utilisant la méthode d'Euler
def MethodeEuler(x,y,vx,vy,dt,Nb_poles):
    acceleration=Acceleration(x,y,X,Y,k,Nb_poles)
    acc_x=acceleration[0]
    acc_y=acceleration[1]
            
    vx_plus_dt=vx+dt*acc_x
    vy_plus_dt=vy+dt*acc_y
            
    x_plus_dt=x+dt*vx
    y_plus_dt=y+dt*vy
    
    return (x_plus_dt,y_plus_dt,vx_plus_dt,vy_plus_dt)



#On crée une fonction qui calcule la trajectoire avec la méthode d'Euler 
def Trajectoire_Euler(x,y,vx,vy,X,Y,dt,tmax,Nb_poles,Rayon,Couleurs):
    t=0
    trajectoire_x=[x]
    trajectoire_y=[y]
    while t<=tmax:
        CA=Condition_Arret(x,y,X,Y,Nb_poles,Rayon)
        if CA==True: #Vérification de la condition d'arrêt
            return (trajectoire_x,trajectoire_y)
        x,y,vx,vy=MethodeEuler(x,y,vx,vy,dt,Nb_poles)
        trajectoire_x.append(x)
        trajectoire_y.append(y)
        t+=dt
            
    return (trajectoire_x,trajectoire_y)



#On crée une condition d'arrêt qui s'applique si la distance entre notre point et le pôle est inférieur au rayon du pôle 
def Condition_Arret(x,y,X,Y,Nb_poles,Rayon):
    for i in range(Nb_poles):
        if Distance(x,y,X,Y,Nb_poles,i)<=Rayon[i]:
            return (True)



##############################################################################
############################ EULER A PAS VARIABLE ############################
##############################################################################


#On calcul les coordonnées de x et de y et la vitesse selon x et selon y en utilisant la méthode d'Euler à pas variable 
def MethodeEuler_pas_variable(x,y,vx,vy,dt,dtmax):
    acceleration=Acceleration(x,y,X,Y,k,Nb_poles)
    acc_x=acceleration[0]
    acc_y=acceleration[1]
    dtmin=10**-8
    eps=10**-7
    
    vx_plus_dt=vx+dt*acc_x
    vy_plus_dt=vy+dt*acc_y
    
    if sqrt(vx**2+vy**2)==0:
        x_plus_dt=x+vx*dt
        y_plus_dt=y+vy*dt
        return(x_plus_dt,y_plus_dt,vx_plus_dt,vy_plus_dt,dt)
    
    Delta_v=sqrt(vx_plus_dt**2+vy_plus_dt**2)-sqrt(vx**2+vy**2)
    A=Delta_v/sqrt(eps+vx**2+vy**2) #On ajoute un terme epsilon très petit pour que le terme sous la racine ne soit pas nulle 
    dt=dtmin+(dtmax-dtmin)*(1/(A**2+1)) #On vait varier notre dt avec une fonction de type (1/1+x**2) et on borne notre dt
    
    x_plus_dt=x+dt*vx
    y_plus_dt=y+dt*vy

    return (x_plus_dt,y_plus_dt,vx_plus_dt,vy_plus_dt,dt)

 
    
#On crée une fonction qui calcule la trajectoire avec la méthode d'Euler à pas variable 
def Trajectoire_Euler_Pas_Variable(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs):
    t=0
    trajectoire_x=[x]
    trajectoire_y=[y]
    while t<=tmax:
        CA=Condition_Arret(x,y,X,Y,Nb_poles,Rayon) #Vérification de la condition d'arrêt
        if CA==True:
            return (trajectoire_x, trajectoire_y)
        x,y,vx,vy,dt=MethodeEuler_pas_variable(x,y,vx,vy,dt,dtmax)
        trajectoire_x.append(x)
        trajectoire_y.append(y)
        t=t+dt
    
    return (trajectoire_x,trajectoire_y)



##############################################################################
############################ RUNGE KUTTA ORDRE 4 #############################
##############################################################################


#On calcul les coordonnées de x et de y et la vitesse selon x et selon y en utilisant la méthode de Runge Kutta à l'ordre 4
# On prend la pente au début de l’intervalle k1 pour faire un pas avec la méthode
# d’Euler jusqu’au milieu de l’intervalle et on obtient une première approximation
# k2 de la pente au milieu.
# Après on répète le pas, mais maintenant avec la pente
# k2 afin d’obtenir une approximation meilleure k3 de la pente au milieu.
# Après on utilise k3 pour aller à la fin de l’intervalle et on utilise l’approximation 
# k4 pour la pente à la fin d’intervalle pour faire le pas final.
def RK4(x,y,vx,vy,X,Y,k,Nb_plots,dt):
    acceleration=Acceleration(x,y,X,Y,k,Nb_poles)
    acc_x=acceleration[0]
    acc_y=acceleration[1]
    
    kx1=dt*vx #Calcul du premier coefficient pour x et y
    ky1=dt*vy
    
    jx1=dt*acc_x #Calcul du premier coefficient pour vx et vy 
    jy1=dt*acc_y
    
    acceleration=Acceleration(x+kx1/2,y+ky1/2,X,Y,k,Nb_poles) #L'accélération est recalculée en fonction des premiers coefficients
    acc_x=acceleration[0]
    acc_y=acceleration[1]    
    
    kx2=dt*(vx+jx1/2)  #Calcul du 2ème coefficient 
    ky2=dt*(vy+jy1/2)
    
    jx2=dt*acc_x
    jy2=dt*acc_y    

    acceleration=Acceleration(x+kx2/2,y+ky2/2,X,Y,k,Nb_poles) #L'accélération est recalculée en fonction des deuxièmes coefficients
    acc_x=acceleration[0]
    acc_y=acceleration[1]    
    
    kx3=dt*(vx+jx2/2)  #Calcul du 3ème coefficient 
    ky3=dt*(vy+jy2/2)
    
    jx3=dt*acc_x
    jy3=dt*acc_y      
    
    acceleration=Acceleration(x+kx3,y+ky3,X,Y,k,Nb_poles) #L'accélération est recalculée en fonction des troisièmes coefficients
    acc_x=acceleration[0]
    acc_y=acceleration[1]    
    
    kx4=dt*(vx+jx3) #Calcul du 4ème coefficient 
    ky4=dt*(vy+jy3)
    
    jx4=dt*acc_x
    jy4=dt*acc_y          
    
    x_plus_dt = x + 1/6*(kx1 + 2*kx2 + 2*kx3 + kx4)
    y_plus_dt = y + 1/6*(ky1 + 2*ky2 + 2*ky3 + ky4)
    
    vx_plus_dt = vx + 1/6*(jx1 + 2*jx2 + 2*jx3 + jx4)
    vy_plus_dt = vy + 1/6*(jy1 + 2*jy2 + 2*jy3 + jy4)
        
    return(x_plus_dt,y_plus_dt,vx_plus_dt,vy_plus_dt)



#On crée une fonction qui calcule la trajectoire avec la méthode Runge-Kutta à l'ordre 4
def Trajectoire_RK4(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs):
    t=0
    trajectoire_x=[x]
    trajectoire_y=[y]
    while t<=tmax:
        CA=Condition_Arret(x,y,X,Y,Nb_poles,Rayon)
        if CA==True:
            return (trajectoire_x, trajectoire_y)
        x,y,vx,vy=RK4(x,y,vx,vy,X,Y,k,Nb_poles,dt)
        trajectoire_x.append(x)
        trajectoire_y.append(y)
        t=t+dt
    
    return (trajectoire_x,trajectoire_y)



##############################################################################
########################### CARTOGRAPHIER LE CHAOS ###########################
##############################################################################


#On effectue une cartographie du chaos selon la méthode choisie, 
def Cartographie_Chaos(x,y,vx,vy,X,Y,Nb_poles,Rayon,Couleurs,METHODE): 
    for l in range (N): #Ligne 
        for c in range (N): #Colonne
            x=l
            y=c
            plt.xlim(0,N)
            plt.ylim(0,N)
            if METHODE == 'Euler':
                TE=Trajectoire_Euler(x,y,vx,vy,X,Y,dt,tmax,Nb_poles,Rayon,Couleurs)
                TX_1=TE[0]
                TY_1=TE[1]
                for i in range (Nb_poles):
                    if sqrt((TX_1[-1]-X[i])**2+(TY_1[-1]-Y[i])**2)<Rayon[i]:
                        plt.scatter(x,y,37,c=Couleurs[i])
        
            if METHODE == 'Euler variable':
                TEPV=Trajectoire_Euler_Pas_Variable(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs)
                TX_2=TEPV[0]
                TY_2=TEPV[1]
                for i in range (Nb_poles):
                    if sqrt((TX_2[-1]-X[i])**2+(TY_2[-1]-Y[i])**2)<Rayon[i]:
                        plt.scatter(x,y,37,c=Couleurs[i])
        
            if METHODE == 'RK4':
                TRK4=Trajectoire_RK4(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs)
                TX_3=TRK4[0]
                TY_3=TRK4[1]
                for i in range (Nb_poles):
                    if sqrt((TX_3[-1]-X[i])**2+(TY_3[-1]-Y[i])**2)<Rayon[i]:
                        plt.scatter(x,y,37,c=Couleurs[i])
                    
    if METHODE == 'Euler':
        plt.title('Cartographie du chaos avec la méthode d\'Euler')
        plt.savefig('Cartographie du Chaos Euler.png', format='png')
    if METHODE == 'Euler variable':
        plt.title('Cartographie du chaos avec la méthode d\'Euler à pas variable')
        plt.savefig('Cartographie du Chaos Euler pas variable.png', format='png')
    if METHODE == 'RK4':
        plt.title('Cartographie du chaos avec la méthode de Runge-Kutta d\'ordre 4')
        plt.savefig('Cartographie du Chaos RK4.png', format='png')
    


def Trajectoire(x,y,vx,vy,X,Y,Nb_poles,Rayon,Couleurs,METHODE):
    x=random.uniform(0,N)
    y=random.uniform(0,N)
    plt.xlim(0,N)
    plt.ylim(0,N)
    if METHODE == 'Euler':
        TE=Trajectoire_Euler(x,y,vx,vy,X,Y,dt,tmax,Nb_poles,Rayon,Couleurs)
        TX_1=TE[0]
        TY_1=TE[1]
        for i in range (Nb_poles):
            if sqrt((TX_1[-1]-X[i])**2+(TY_1[-1]-Y[i])**2)<Rayon[i]:
                plt.plot(TE[0],TE[1],marker='',label='Méthode Euler',c=Couleurs[i])
                plt.title('Trajectoire avec la méthode d\'Euler')
                
    if METHODE == 'Euler variable':
        TEPV=Trajectoire_Euler_Pas_Variable(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs)
        TX_2=TEPV[0]
        TY_2=TEPV[1]
        for i in range (Nb_poles):
            if sqrt((TX_2[-1]-X[i])**2+(TY_2[-1]-Y[i])**2)<Rayon[i]:
                plt.plot(TEPV[0],TEPV[1],marker='',label='Méthode Euler à Pas Variable',c=Couleurs[i])
                plt.title('Trajectoire avec la méthode d\'Euler à pas variable')
                
    if METHODE == 'RK4':
        TRK4=Trajectoire_RK4(x,y,vx,vy,X,Y,dtmax,dt,Nb_poles,Rayon,Couleurs)
        TX_3=TRK4[0]
        TY_3=TRK4[1]
        for i in range (Nb_poles):
            if sqrt((TX_3[-1]-X[i])**2+(TY_3[-1]-Y[i])**2)<Rayon[i]:
                plt.plot(TRK4[0],TRK4[1],marker='',label='Méthode Runge-Kutta ordre 4',c=Couleurs[i])
                plt.title('Trajectoire avec la méthode de Runge-Kutta d\'ordre 4')
                
#On appelle la fonction Cartographie_Chaos en précisant la méthode utilisée :  
#FONCTION POUR VISUALISER LA CARTOGRAPHIE DU CHAOS DETERMINISTE AVEC LA METHODE CHOISIE
#POUR CHANGER LA METHODE, METTRE 'Euler' OU 'Euler variable' DANS LES PARAMETRES DE LA FONCTION CI-DESSOUS :          
Cartographie_Chaos(x,y,vx,vy,X,Y,Nb_poles,Rayon,Couleurs,'RK4')

 
#On appelle la fonction Trajectoire en précisant la méthode utilisée :                
#FONCTION POUR VISUALISER LA TRAJECTOIRE POUR x ET y CHOISI AVEC LA METHODE ASSOCIEE 
#POUR CHANGER LA METHODE, METTRE 'Euler' OU 'Euler variable' DANS LES PARAMETRES DE LA FONCTION CI-DESSOUS : 
# Trajectoire(x,y,vx,vy,X,Y,Nb_poles,Rayon,Couleurs,'RK4')

##############################################################################
######### VITESSE INITIALE NON NULLE DANS LA DEUXIEME PARTIE DU CODE #########
##############################################################################


##############################################################################
################## FIN DU CODE CONCERNANT LA CARTOGRAPHIE ####################
##############################################################################






